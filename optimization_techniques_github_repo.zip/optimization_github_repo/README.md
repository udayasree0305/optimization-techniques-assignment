# Optimization Techniques Assignment

This repository contains my Python implementation for the Optimization Techniques assignment.

## Contents

### 1. Big-M Simplex Method
Folder: `Big-M/`

The program solves a product-mix linear programming problem using the Big-M Simplex Method.

The model is:

Maximize

Z = 40x1 + 30x2

subject to:

- x1 + x2 <= 40
- 2x1 + x2 >= 50
- x1 + 2x2 <= 60
- x1, x2 >= 0

For the >= constraint, a surplus variable and an artificial variable are introduced. The artificial variable is penalized using the Big-M approach.

Result:
- x1 = 40
- x2 = 0
- Maximum Z = 1600

### 2. Transportation Problem
Folder: `Transportation/`

The transportation problem has 3 sources and 4 destinations.

| Source | D1 | D2 | D3 | D4 | Supply |
|---|---:|---:|---:|---:|---:|
| S1 | 1 | 4 | 15 | 6 | 20 |
| S2 | 7 | 20 | 18 | 2 | 30 |
| S3 | 10 | 6 | 1 | 1 | 25 |
| Demand | 10 | 25 | 15 | 25 | |

The program first obtains an initial basic feasible solution using Vogel's Approximation Method (VAM). The solution is then checked and improved using the MODI method.

Initial VAM cost:

275

Optimal allocation obtained after MODI:

- S1 -> D1 = 5
- S1 -> D2 = 15
- S2 -> D1 = 5
- S2 -> D4 = 25
- S3 -> D2 = 10
- S3 -> D3 = 15

Minimum transportation cost:

225

## How to run

Python 3 is required.

Run the Big-M program:

```bash
python Big-M/big_m_simplex.py
```

Run the transportation program:

```bash
python Transportation/transportation_vam_modi.py
```

The programs use NumPy.

Install it if required:

```bash
pip install numpy
```

## Assignment Report

The written assignment is available in the `Assignment` folder.

## Note

The programs print the intermediate MODI information such as the u and v values and opportunity-cost table so that the improvement process can be checked rather than only displaying the final answer.
