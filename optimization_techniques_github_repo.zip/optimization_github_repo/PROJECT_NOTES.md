# Project notes

I used two separate case studies for the assignment.

For the Big-M part, I used a small product-mix problem because it has a
>= constraint, so the need for a surplus variable and an artificial variable
can be demonstrated clearly.

For the transportation part, I used a balanced 3 x 4 transportation table.
I used VAM to get the starting solution and MODI to check optimality and
improve the allocation.

The code prints the important intermediate values so that the calculations
can be verified while running the programs.
